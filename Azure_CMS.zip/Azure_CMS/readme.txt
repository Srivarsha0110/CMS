# Article CMS - Azure Deployment (Project Submission)

This repository contains my completed project for deploying a Flask-based **Article Content Management System (CMS)** to **Microsoft Azure App Service** as part of the Udacity Cloud Developer Nanodegree.

---

## Project Overview
The CMS is a simple Flask web application that allows authenticated users to:
- Log in via **local admin credentials** or **Microsoft Entra ID (OAuth2)**.
- Create, edit, and view articles with image uploads.
- Store images in **Azure Blob Storage** and data in **Azure SQL Database**.

The application is deployed to **Azure App Service** with **GitHub Actions CI/CD**.

---

## Deployment Details
- **Platform:** Azure App Service (Python 3.10)
- **CI/CD:** GitHub Actions (Deployment Center)
- **Database:** Azure SQL Database
- **Storage:** Azure Blob Storage
- **Authentication:** Microsoft Entra ID (OAuth2)
- **Logging:** Azure App Service Log Stream

App URL: https://udacitycmsa-b2gecxbec2ckbqf8.eastus-01.azurewebsites.net/home
